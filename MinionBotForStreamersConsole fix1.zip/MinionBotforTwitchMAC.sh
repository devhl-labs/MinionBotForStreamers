#!/bin/sh
sudo dotnet MinionBotForStreamersConsole.dll