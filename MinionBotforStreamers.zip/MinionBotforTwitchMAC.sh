#!/bin/sh
sudo dotnet my.dll